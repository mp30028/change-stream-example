#!/bin/bash

docker-compose up

sleep 5

docker exec mongo1 ./scripts/rs-init.sh