#!/bin/bash

mongosh  <<EOF
var config = {
    "_id": "dbrs",
    "version": 1,
    "members": [
        {
            "_id": 0,
            "host": "mongo1",
            "priority": 1,
            "votes": 1
        },
        {
            "_id": 1,
            "host": "mongo2",
            "priority": 0,
            "votes": 0
        },
        {
            "_id": 2,
            "host": "mongo3",
            "priority": 0,
            "votes": 0
        }
    ]
};
rs.initiate(config, { force: true });
rs.status();
EOF